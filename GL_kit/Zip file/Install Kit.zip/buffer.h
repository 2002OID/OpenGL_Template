// ���� �ʱ�ȭ
#ifndef MODEL_BUFFER_H
#define MODEL_BUFFER_H
#include "config.h"

void setBuffer(int idx, int bufferMode);

#endif
